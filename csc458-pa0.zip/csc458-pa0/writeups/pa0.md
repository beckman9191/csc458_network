Programming Assignment 0 Writeup
====================

My name: Zhengnan Zhu

My UTORID : zhuzhe25

I collaborated with: [list utorids here]

I would like to credit/thank these classmates for their help: [list utorids here]

This programming assignment took me about 1 hours to do.

My public ip address output from webget was: 66.23.57.92

- Optional: I had unexpected difficulty with: [describe]

- Optional: I think you could make this lab better by: [describe]

- Optional: I was surprised by: [describe]

- Optional: I'm not sure about: [describe]
